<script>
  import Vue from 'vue';

  const EventHandler = new Vue();
  export default EventHandler;
</script>
