<template>
  <footer class="ct-footer">
    <div class="container-gallery">
      <ul class="ct-footer-list text-center-sm">
        <li>
          <h2 class="ct-footer-list-header">
            علی بابا
          </h2>
          <ul>
            <li>
              <a href="">درباره ی ما</a>
            </li>
            <li>
              <a href="">تماس با ما</a>
            </li>
            <li>
              <a href="">چرا علی بابا</a>
            </li>
            <li>
              <a href="">باشگاه مشتریان</a>
            </li>
            <li>
              <a href="">قوانین و مقررات</a>
            </li>
            <li>
              <a href="">راهنمای خرید</a>
            </li>
            <li>
              <a href="">پرسش و پاسخ</a>
            </li>
            <li>
              <a href="">مجله ی علی بابا</a>
            </li>
            <li>
              <a href="">فرصت های شغلی</a>
            </li>
          </ul>
        </li>
        <li>
          <h2 class="ct-footer-list-header">
            اطلاعات تکمیلی
          </h2>
          <ul>
            <li>
              <a href="">بلیط چارتر</a>
            </li>
            <li>
              <a href="">راهنمای خرید بلیط هواپیما(داخلی)</a>
            </li>
            <li>
              <a href="">راهنمای خرید بلیط هواپیما(خارجی)</a>
            </li>
            <li>
              <a href="">راهنمای خرید بلیط قطار</a>
            </li>
            <li>
              <a href="">راهنمای خرید بلیط اتوبوس</a>
            </li>
            <li>
              <a href="">راهنمای رزرو هتل خارجی</a>
            </li>
            <li>
              <a href="">راهنمای استرداد بلیط</a>
            </li>
            <li>
              <a href="">بلیط قطار</a>
            </li>
            <li>
              <a href="">خرید بلیط هواپیما خارجی</a>
            </li>
            <li>
              <a href="">اطلاعات فرودگا‌هی</a>
            </li>
            <li>
              <a href="">اشیوه‌نامه حقوق مسافر</a>
            </li>
          </ul>
        </li>
        <li>
          <h2 class="ct-footer-list-header">
            اپلیکیش علی بابا
          </h2>
          <p class="ct-footer-list-paragraph">با نصب اپلیکیشن علی‌بابا بلیط همه سفرها در جیب شماست. آسان‌ترین،
            کامل‌ترین و مطمئن‌ترین روش تهیه بلیط و هتل را با اپلیکیشن علی‌بابا تجربه کنید.</p>
          <a href="">
            <img class="ct-footer-list-img" src="../images/bazar.svg"/>
          </a>
          <a href="">
            <img class="ct-footer-list-img" src="../images/alibaba-apple.svg"/>
          </a>
          <a href="">
            <img class="ct-footer-list-img" src="../images/google-play.svg"/>
          </a>
          <a href="">
            <img class="ct-footer-list-img" src="../images/iapps.svg"/>
          </a>

        <li>
          <img class="ct-footer-list-logo" src="../images/alibaba-logo-eng.svg"/>
          <p class="ct-footer-list-paragraph">تلفن پشتیبانی: ۰۲۱ - ۴۳۹۰۰۰۰۰ | ۰۲۱ - ۴۹۲۷۵۰۰۰</p>
          <div>
            <a href="">
              <img class="ct-footer-list-img" src="../images/etehadie.png"/>
            </a>
            <a href="">
              <img class="ct-footer-list-img" src="../images/neshan-melli.png"/>
            </a>
            <a href="">
              <img class="ct-footer-list-img" src="../images/tejarat-electronic.png"/>
            </a>
            <a href="">
              <img class="ct-footer-list-img" src="../images/hoghughe-mosafer.svg"/>
            </a>
            <a href="">
              <img class="ct-footer-list-img" src="../images/damaneie-nerkh-belit.png"/>
            </a>
            <a href="">
              <img class="ct-footer-list-img" src="../images/havapeima-keshvari.svg"/>
            </a>
          </div>
        </li>
      </ul>
    </div>
    <div class="ct-footer-post">
      <div class="container-gallery">
        <div class="inner-left">
          <ul>
            <li>
              <a href="">
                <img src="../images/instagram.svg"/>
              </a>
            </li>
            <li>
              <a href="">
                <img src="../images/linkedin.svg"/>
              </a>
            </li>
            <li>
              <a href="">
                <img src="../images/aparat.png"/>
              </a>
            </li>
          </ul>
        </div>
        <div class="inner-right">
          <p>
            کلیه حقوق این سایت محفوظ و متعلق به آژانس هواپیمایی و جهانگردی علی بابا می‌باشد.
          </p>
        </div>
      </div>
    </div>
  </footer>
</template>
