<template>
  <div id="hotel-reserve" class="container container-reserve">
    <div class="row col-sm-3 offset-sm-9" style="margin-bottom: 30px; padding: 0 0">
      <div style="border-bottom: 2px solid orange;padding: 5px 0px">
        <svg style="display: inline" fill="" width="32px" height="32px" viewBox="0 0 16 16" version="1.1"
             xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="svg-icon"
             data-v-21eb7522="">
          <defs>
            <path
              d="M1.99998791,10.6666667 L13.9999154,10.6666667 L13.9999154,8 C13.9999154,7.26362033 13.4029653,6.66666667 12.6665901,6.66666667 L3.33331318,6.66666667 C2.59693797,6.66666667 1.99998791,7.26362033 1.99998791,8 L1.99998791,10.6666667 Z M7.99995164,6 L12.6665901,6 C13.7711529,6 14.666578,6.8954305 14.666578,8 L14.666578,11.3333333 L1.33332527,11.3333333 L1.33332527,8 C1.33332527,6.8954305 2.22875036,6 3.33331318,6 L7.99995164,6 Z M6.66662637,10.6666667 L6.66662637,10 C6.66662637,9.63181017 6.36815134,9.33333333 5.99996373,9.33333333 L4.66663846,9.33333333 C4.29845085,9.33333333 3.99997582,9.63181017 3.99997582,10 L3.99997582,10.6666667 L6.66662637,10.6666667 Z M4.66663846,8.66666667 L5.99996373,8.66666667 C6.73633895,8.66666667 7.333289,9.26362033 7.333289,10 L7.333289,11.3333333 L3.33331318,11.3333333 L3.33331318,10 C3.33331318,9.26362033 3.93026324,8.66666667 4.66663846,8.66666667 Z M11.9999275,10.6666667 L11.9999275,10 C11.9999275,9.63181017 11.7014524,9.33333333 11.3332648,9.33333333 L9.99993955,9.33333333 C9.63175194,9.33333333 9.33327691,9.63181017 9.33327691,10 L9.33327691,10.6666667 L11.9999275,10.6666667 Z M9.99993955,8.66666667 L11.3332648,8.66666667 C12.06964,8.66666667 12.6665901,9.26362033 12.6665901,10 L12.6665901,11.3333333 L8.66661428,11.3333333 L8.66661428,10 C8.66661428,9.26362033 9.26356434,8.66666667 9.99993955,8.66666667 Z M1.99998791,11.3333333 C1.2636127,11.3333333 0.666662637,11.930287 0.666662637,12.6666667 C0.666662637,13.4030463 1.2636127,14 1.99998791,14 L13.9999154,14 C14.7362906,14 15.3332406,13.4030463 15.3332406,12.6666667 C15.3332406,11.930287 14.7362906,11.3333333 13.9999154,11.3333333 L1.99998791,11.3333333 Z M2.66665055,14.6666667 L1.99998791,14.6666667 C0.895425087,14.6666667 1.35269933e-16,13.7712362 0,12.6666667 C-1.35269933e-16,11.5620972 0.895425087,10.6666667 1.99998791,10.6666667 L13.9999154,10.6666667 C15.1044782,10.6666667 15.9999033,11.5620972 15.9999033,12.6666667 C15.9999033,13.7712362 15.1044782,14.6666667 13.9999154,14.6666667 L13.3332527,14.6666667 L13.3332527,15.6666687 C13.3332527,15.8507625 13.1840152,16 12.9999214,16 C12.8158276,16 12.6665901,15.8507625 12.6665901,15.6666687 L12.6665901,14.6666667 L3.33331318,14.6666667 L3.33331318,15.6666687 C3.33331318,15.8507625 3.18407567,16 2.99998187,16 C2.81588806,16 2.66665055,15.8507625 2.66665055,15.6666687 L2.66665055,14.6666667 Z M5.18490415,4.34154953 C5.03172884,4.44366702 4.82477365,4.40227573 4.72265678,4.2490995 C4.62053991,4.09592327 4.66193095,3.88896682 4.81510625,3.78684934 L7.07549233,2.27991618 C7.63532129,1.90669461 8.36465283,1.90669461 8.9244818,2.27991618 L11.1848679,3.78684934 C11.3380432,3.88896682 11.3794342,4.09592327 11.2773174,4.2490995 C11.1752005,4.40227573 10.9682453,4.44366702 10.81507,4.34154953 L8.55468391,2.83461637 C8.21878653,2.61068343 7.7811876,2.61068343 7.44529022,2.83461637 L5.18490415,4.34154953 Z M0.506694279,4.94335685 C0.349441618,5.03907644 0.144367559,4.98919326 0.0486485475,4.83193965 C-0.0470704638,4.67468603 0.00281241558,4.46961073 0.160065077,4.37389115 L6.78679779,0.34020337 C7.53200067,-0.113401123 8.46799933,-0.113401123 9.21320221,0.34020337 L15.8399349,4.37389115 C15.9971876,4.46961073 16.0470705,4.67468603 15.9513515,4.83193965 C15.8556324,4.98919326 15.6505584,5.03907644 15.4933057,4.94335685 L8.86657301,0.909669074 C8.33428524,0.585665864 7.66571476,0.585665864 7.13342699,0.909669074 L0.506694279,4.94335685 Z"
              id="path-1"></path>
          </defs>
          <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="International-Hotel---PDP---cancel-rules-expanded--Desktop"
               transform="translate(-451.000000, -330.000000)">
              <g id="Group-12" transform="translate(200.000000, 236.000000)">
                <g id="Group-13" transform="translate(20.000000, 17.000000)">
                  <g id="Icon-/-Hotel-&amp;-Facilities-/-bed" transform="translate(231.000000, 77.000000)">
                    <mask id="mask-2-bed" fill="white">
                      <use xlink:href="#path-1"></use>
                    </mask>
                    <use id="bed" fill="currentColor" fill-rule="nonzero" xlink:href="#path-1"></use>
                  </g>
                </g>
              </g>
            </g>
          </g>
        </svg>
        <h6 style="padding: 0 2px; display: inline"><b>اتاق های قابل رزرو</b></h6>
      </div>
    </div>

    <div class="row" v-if="errors.length" dir="ltr">
      <ul>
        <li v-for="error in errors" class="alert alert-danger">{{ error }}</li>
      </ul>
    </div>

    <div class="row" style="background-color: white; padding: 25px 0; border:1px solid lightgray;">
      <div class="col-sm-2 reserve-items-background" style="cursor: pointer">
        <date-picker format="jYYYY-jMM-jDD" element="entrance-date" v-model="entranceDate"></date-picker>
        <div class="reserve-items" id="entrance-date">
          <p>تاریخ ورود</p>
          <p>انتخاب کنید</p>
        </div>
      </div>
      <div class="col-sm-2 reserve-items-background" style="cursor: pointer">
        <date-picker format="jYYYY-jMM-jDD" element="exit-date" v-model="exitDate"></date-picker>
        <div class="reserve-items" id="exit-date">
          <p>تاریخ خروج</p>
          <p>انتخاب کنید</p>
        </div>
      </div>

      <div class="col-sm-2 offset-sm-2 reserve-items-background" style="cursor: pointer; border: none"
           @click="showPersonSelection" v-click-outside="hidePersonSelection">
        <div class="reserve-items">
          <p>مسافران</p>
          <p>{{changePersonSelection()}}</p>
        </div>
        <div class="dropdown-person-selection" style="padding: 10px 0" dir="rtl" v-if="personSelection">
          <p style="color: orange; font-size: 15px; padding: 10px;">تعداد افراد را انتخاب کنید</p>
          <hr style="width: 70%; display: block; margin: 15px auto;" color="lightgray">

          <div style="padding: 10px;">
            <p style="color: gray;float: right; padding: 10px 0">بزرگسال ({{toPersianNum(12)}} سال به بالا)</p>
            <span class="add-minus" style="float: left"
                  @click="numAdults = numAdults > 0 ? numAdults - 1 : 0">-</span>
            <p style="padding: 10px; float: left">{{toPersianNum(numAdults)}}</p>
            <span class="add-minus" style="float: left" @click="numAdults = numAdults + 1">+</span>
          </div>

          <div style="padding: 10px;margin-top: 10%">
            <p style="color: gray;float: right; padding: 1px 1px">کودک ({{toPersianNum(0)}} تا {{toPersianNum(12)}}
              سال)</p>
            <span class="add-minus" style="float: left"
                  @click="numChildren = numChildren > 0 ? numChildren - 1 : 0">-</span>
            <p style="padding: 10px; float: left">{{toPersianNum(numChildren)}}</p>
            <span class="add-minus" style="float: left" @click="numChildren = numChildren + 1">+</span>
          </div>
        </div>

      </div>

      <div class="col-sm-4" style="padding: 25px 60px">
        <button class="btn btn-warning" style="color: white" @click="findAvailableRooms">مشاهده اتاق های موجود</button>
      </div>
    </div>

    <template v-for="r in rooms">
      <div class="row reserve-container">
        <div class="col-sm-7">
          <div class="col-sm-4 offset-sm-8">
            <h5>{{r.name}}</h5>
          </div>
          <div class="col-sm-12" style="padding: 15px 0px">
            <p class="reserve-properties">
              <span id="SPAN_1"><small id="SMALL_2">BB</small></span>
              {{meal(r.breakfast)}} |</p>
            <p class="reserve-properties">
              <span class="person-reserve-icon nav-sing-in"></span> {{personsForRoom()}} |</p>
            <!--            <p class="reserve-properties">قیمت برای یک شب: {{toPersianNum(r.price)}} ریال |</p>-->
            <p class="reserve-properties">قیمت برای یک شب: {{toPersianNum(10)}} ریال |</p>
            <p class="reserve-properties" style="color: darkorange">غیر قابل استرداد</p>
          </div>
        </div>
        <div class="col-sm-1">
          <div class="vl"></div>
        </div>
        <div class="col-sm-4">
          <div class="col-sm-12">
            <p class="reserve-properties" style="font-size: 15px">جمع قیمت برای {{toPersianNum(numOfDays)}} شب:
              <!--              {{toPersianNum(numOfDays * r.price)}} ریال</p>-->
              {{toPersianNum(100)}} ریال</p>

          </div>
          <div class="col-sm-12">
            <button class="btn btn-primary" style="width: 100%; font-size: 15px" @click="reserveRoom(r._id)">رزرو این
              اتاق
            </button>
          </div>
        </div>
      </div>
    </template>

    <div class="row" v-if="userType === 'admin'">
      <div class="col-sm-12" style="margin: 40px 40%; width: 20% ">
        <router-link :to="{name: 'add-room', params: {id: $route.params.id}}" tag="button" style="color: white"
                     class="btn btn-warning" exact>اتاق جدید اضافه کنید
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
  let xml_json_converter = require("xml-js");
  let moment = require('moment-jalaali');

  import {persianNumConverter} from '../PersianNumConverter'

  export default {
    data() {
      return {
        entranceDate: '',
        exitDate: '',
        numOfDays: 0,
        numAdults: 2,
        numChildren: 0,
        personSelection: false,
        rooms: [],
        userType: '',
        errors: []
      }
    },
    mixins: [persianNumConverter],
    props: ['id'],
    methods: {
      meal(haveBreakfast) {
        return haveBreakfast ? 'به همراه صبحانه' : 'بدون وعده غذایی'
      },
      findAvailableRooms() {
        this.errors = [];
        if (this.entranceDate === '') {
          this.errors.push('Please specify entrance date');
        }
        if (this.exitDate === '') {
          this.errors.push('Please specify exit date');
        }
        if (this.numChildren === 0 && this.numAdults === 0) {
          this.errors.push('Please add some person');
        }

        if (this.errors.length === 0) {
          console.log(this.userType);
          let entranceDate = moment(this.entranceDate, "jYYYY-jMM-jDD");
          let exitDate = moment(this.exitDate, "jYYYY-jMM-jDD");
          this.numOfDays = exitDate.jDayOfYear() - entranceDate.jDayOfYear();

          this.$http.post('rooms/hotel/' + this.$route.params.id, {
            entranceDate: new Date(entranceDate._d),
            exitDate: new Date(exitDate._d),
            numAdults: this.numAdults,
            numChildren: this.numChildren

          })
            .then(response => {
              return response.json()
            }).then(data => {
            this.rooms = data;
          });
        }
      },
      showPersonSelection() {
        this.personSelection = true;
      },
      hidePersonSelection() {
        this.personSelection = false;
      },
      changePersonSelection() {
        let adult = this.numAdults > 0 ? this.toPersianNum(this.numAdults) + ' بزرگسال' : "";
        let children = this.numChildren > 0 ? this.toPersianNum(this.numChildren) + ' کودک ' : "";
        let room = this.toPersianNum(1) + ' اتاق';
        if (this.numChildren > 0 && this.numAdults > 0)
          return adult + '، ' + children + '، ' + room;
        else if (this.numChildren === 0 && this.numAdults > 0)
          return adult + '، ' + room;
        else if (this.numChildren > 0 && this.numAdults === 0)
          return children + '، ' + room;
        else
          return room;
      },
      personsForRoom() {
        let adult = this.numAdults > 0 ? this.toPersianNum(this.numAdults) + ' بزرگسال' : "";
        let children = this.numChildren > 0 ? this.toPersianNum(this.numChildren) + ' کودک ' : "";
        if (this.numChildren > 0 && this.numAdults > 0)
          return adult + '، ' + children;
        else if (this.numChildren === 0 && this.numAdults > 0)
          return adult;
        else if (this.numChildren > 0 && this.numAdults === 0)
          return children;
        else
          return "تعداد افراد نا مشخص";
      },
      reserveRoom(id) {

        const user = JSON.parse(localStorage.getItem('userData'));
        const userID = user._id;
        let entranceDate = new Date(moment(this.entranceDate, "jYYYY-jMM-jDD", 'en')._d);
        let exitDate = new Date(moment(this.exitDate, "jYYYY-jMM-jDD")._d);

        const reserve = {
          userID: userID,
          roomID: id,
          entranceDate: entranceDate,
          exitDate: exitDate
        };
        this.$http.post('reserve', reserve)
          .then(response => {
            console.log(response);
            alert("Reserved");
          })
      }
    },
    mounted() {
      const user = JSON.parse(localStorage.getItem('userData'));
      this.userType = user.role;
    }
  }
</script>

<style src="../../css/bootstrap.css" scoped></style>

<style scoped>
  .container-reserve {
    margin-top: 5%;
    border: 40px solid whitesmoke;
    margin-right: 10%;
    width: 70%;
    /*height: 200px;*/
    background-color: whitesmoke;
  }

  .reserve-items {
    padding: 0 20px;
  }

  .reserve-items p:last-child {
    font-size: 12px;
  }

  .reserve-items-background {
    border-left: 1px solid gray;
  }

  .reserve-items-background:hover {
    background-color: whitesmoke;
  }

  .reserve-container {
    margin: 20px;
    padding-top: 15px;
    background-color: white;
  }

  .reserve-properties {
    font-size: 10px;
    color: gray;
    display: inline;
    padding: 4px;
  }

  .vl {
    border-left: 1px solid darkgray;
    margin: auto;
    height: 70px;
  }

  #SPAN_1 {
    box-sizing: border-box;
    color: rgb(41, 121, 255);
    /*cursor: pointer;*/
    direction: rtl;
    display: inline-block;
    height: 20px;
    text-align: right;
    text-decoration: none solid rgb(41, 121, 255);
    text-size-adjust: 100%;
    vertical-align: text-bottom;
    white-space: nowrap;
    width: 29.0125px;
    column-rule-color: rgb(41, 121, 255);
    perspective-origin: 14.5px 10px;
    transform-origin: 14.5063px 10px;
    user-select: none;
    caret-color: rgb(41, 121, 255);
    background: rgb(226, 237, 255) none repeat scroll 0% 0% / auto padding-box border-box;
    border: 1px solid rgb(41, 121, 255);
    border-radius: 2px;
    font: 500 14px / 19px IranSans, sans-serif;
    list-style: outside none none;
    margin: 0px 0px 0px 4px;
    outline: rgb(41, 121, 255) none 0px;
    padding: 0px 6px;
  }

  /*#SPAN_1*/

  #SPAN_1:after {
    box-sizing: border-box;
    color: rgb(41, 121, 255);
    /*cursor: pointer;*/
    direction: rtl;
    text-align: right;
    text-decoration: none solid rgb(41, 121, 255);
    text-size-adjust: 100%;
    white-space: nowrap;
    column-rule-color: rgb(41, 121, 255);
    user-select: none;
    caret-color: rgb(41, 121, 255);
    border: 0px none rgb(41, 121, 255);
    font: 500 14px / 19px IranSans, sans-serif;
    list-style: outside none none;
    outline: rgb(41, 121, 255) none 0px;
  }

  /*#SPAN_1:after*/

  #SPAN_1:before {
    box-sizing: border-box;
    color: rgb(41, 121, 255);
    /*cursor: pointer;*/
    direction: rtl;
    text-align: right;
    text-decoration: none solid rgb(41, 121, 255);
    text-size-adjust: 100%;
    white-space: nowrap;
    column-rule-color: rgb(41, 121, 255);
    user-select: none;
    caret-color: rgb(41, 121, 255);
    border: 0px none rgb(41, 121, 255);
    font: 500 14px / 19px IranSans, sans-serif;
    list-style: outside none none;
    outline: rgb(41, 121, 255) none 0px;
  }

  /*#SPAN_1:before*/

  #SMALL_2 {
    box-sizing: border-box;
    color: rgb(41, 121, 255);
    /*cursor: pointer;*/
    direction: rtl;
    text-align: right;
    text-decoration: none solid rgb(41, 121, 255);
    text-size-adjust: 100%;
    white-space: nowrap;
    column-rule-color: rgb(41, 121, 255);
    perspective-origin: 0px 0px;
    transform-origin: 0px 0px;
    user-select: none;
    caret-color: rgb(41, 121, 255);
    border: 0px none rgb(41, 121, 255);
    font: 500 11.9px / 19px IranSans, sans-serif;
    list-style: outside none none;
    outline: rgb(41, 121, 255) none 0px;
  }

  /*#SMALL_2*/

  #SMALL_2:after {
    box-sizing: border-box;
    color: rgb(41, 121, 255);
    /*cursor: pointer;*/
    direction: rtl;
    text-align: right;
    text-decoration: none solid rgb(41, 121, 255);
    text-size-adjust: 100%;
    white-space: nowrap;
    column-rule-color: rgb(41, 121, 255);
    user-select: none;
    caret-color: rgb(41, 121, 255);
    border: 0px none rgb(41, 121, 255);
    font: 500 11.9px / 19px IranSans, sans-serif;
    list-style: outside none none;
    outline: rgb(41, 121, 255) none 0px;
  }

  /*#SMALL_2:after*/

  #SMALL_2:before {
    box-sizing: border-box;
    color: rgb(41, 121, 255);
    /*cursor: pointer;*/
    direction: rtl;
    text-align: right;
    text-decoration: none solid rgb(41, 121, 255);
    text-size-adjust: 100%;
    white-space: nowrap;
    column-rule-color: rgb(41, 121, 255);
    user-select: none;
    caret-color: rgb(41, 121, 255);
    border: 0px none rgb(41, 121, 255);
    font: 500 11.9px / 19px IranSans, sans-serif;
    list-style: outside none none;
    outline: rgb(41, 121, 255) none 0px;
  }

  .add-minus {
    box-sizing: border-box;
    color: rgb(255, 165, 0);
    cursor: pointer;
    direction: rtl;
    display: inline-block;
    height: 30px;
    text-align: center;
    text-decoration: none solid rgb(255, 165, 0);
    text-size-adjust: 100%;
    width: 30px;
    column-rule-color: rgb(255, 165, 0);
    perspective-origin: 15px 15px;
    transform-origin: 15px 15px;
    caret-color: rgb(255, 165, 0);
    border: 1px solid rgb(255, 165, 0);
    border-radius: 100%;
    font: 300 15.4px / 30px IranSans, sans-serif;
    outline: rgb(255, 165, 0) none 0px;
    padding: 1px 0px 0px;
    transition: all 0.15s ease 0s;
  }

  /*.add-minus*/

  .add-minus:after {
    box-sizing: border-box;
    color: rgb(255, 165, 0);
    cursor: pointer;
    direction: rtl;
    text-align: center;
    text-decoration: none solid rgb(255, 165, 0);
    text-size-adjust: 100%;
    column-rule-color: rgb(255, 165, 0);
    caret-color: rgb(255, 165, 0);
    border: 0px none rgb(255, 165, 0);
    font: 300 15.4px / 30px IranSans, sans-serif;
    outline: rgb(255, 165, 0) none 0px;
  }

  /*.add-minus:after*/

  .add-minus:before {
    box-sizing: border-box;
    color: rgb(255, 165, 0);
    cursor: pointer;
    direction: rtl;
    text-align: center;
    text-decoration: none solid rgb(255, 165, 0);
    text-size-adjust: 100%;
    column-rule-color: rgb(255, 165, 0);
    perspective-origin: 0px 0px;
    transform-origin: 0px 0px;
    caret-color: rgb(255, 165, 0);
    border: 0px none rgb(255, 165, 0);
    font: 300 15.4px / 30px IranSans, sans-serif;
    outline: rgb(255, 165, 0) none 0px;
  }

  .add-minus:hover {
    background-color: rgb(255, 165, 0);
  }


  /*#SMALL_2:before*/


</style>
