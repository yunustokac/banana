<template>
  <div style="scroll-behavior: smooth">
    <router-view></router-view>
  </div>
</template>

<script>
</script>
