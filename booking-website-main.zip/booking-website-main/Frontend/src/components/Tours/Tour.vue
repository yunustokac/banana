<template>
  <div class="tour">
    <div class="row">
      <div class="column">
        <div class="card-tour">
          <img src="../../images/tour3.svg">
          <div class="container-card">
            <p><b>تنوع تورهای داخلی و خارجی</b></p>
            <p>شخصی سازی انواع تور برای مسافران</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card-tour">
          <img src="../../images/tour2.svg">
          <div class="container-card">
            <p><b>قیمت رقابتی تورهای داخلی و خارجی </b></p>
            <p>قیمت‌های شفاف بدون پرداخت هزینه‌های جانبی</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card-tour">
          <img src="../../images/tour1.svg">
          <div class="container-card">
            <p><b>مشاوره و پشتیبانی تخصصی رایگان</b></p>
            <p>مشاوره قبل و حین سفر توسط سفریار اختصاصی</p>
          </div>
        </div>
      </div>
    </div>
  </div>

</template>
