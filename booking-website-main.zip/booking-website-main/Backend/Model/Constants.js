const consts = {
  URL: 'mongodb://localhost/alibaba'
};

module.exports = consts;
